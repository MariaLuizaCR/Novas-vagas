function Header() {
    return (
        <header>
        <h1>OpenBoard</h1>
        <div>
            <a href="">Entrar</a>
            <button className="btn">Publicar Vaga - $299</button>
        </div>
    </header>
    )
}

export default Header;