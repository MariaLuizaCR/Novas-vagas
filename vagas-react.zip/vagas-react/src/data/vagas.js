const vagalist = [
    {
        id: 1,
        empresa: "Malu Soluções",
        cargo: "DEV",
        salario: "R$ 5 mil",
        modelo: "remoto",
        area: "Engenharia",
        publicada: "4h",
    },
    {
        id: 2,
        empresa: "Malu Tecnologia",
        cargo: "Suporte",
        salario: "R$ 3.500",
        modelo: "CLT",
        area: "Engenharia",
        publicada: "6h",
    },
    {
        id: 3,
        empresa: "Malu Empresas",
        cargo: "Marketing",
        salario: "R$ 2.500",
        modelo: "CLT",
        area: "Marketing",
        publicada: "6h",
    }

]

export default vagalist;